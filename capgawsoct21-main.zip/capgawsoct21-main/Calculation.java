package com.capg.corejava.junit5;

public class Calculation {
	
	public int addition(int a,int b)
	{
		return a+b;
	}
	
	public int subtraction(int x,int y)
	{
		return x-y;
	}
	
	public int multiplication(int d1,int d2)
	{
		return d1*d2;
	}
	

}
